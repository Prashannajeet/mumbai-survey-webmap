KURLA TOPOGRAPHICAL SURVEY - VECTOR SHAPEFILE DELIVERY

Coordinate reference system: WGS 84 / UTM Zone 43N (EPSG:32643)

Each vector layer is stored in a separate numbered folder. Keep all files
inside each folder together: SHP geometry, SHX index, DBF attributes, PRJ
coordinate reference and CPG text-encoding file.

The building-footprint dataset is excluded in accordance with the latest
deliverable instruction. Raster DEM and DSM products are not shapefiles.
